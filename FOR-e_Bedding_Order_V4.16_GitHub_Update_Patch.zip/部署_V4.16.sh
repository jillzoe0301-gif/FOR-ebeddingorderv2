#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/FOR-ebeddingorderv2

git fetch origin
git checkout main
git pull --rebase origin main

git add index.html package.json package-lock.json CHANGELOG_V4.16.md README_V4.16.md
git commit -m "Add accounting batch full order details download V4.16" || true
git push origin main

echo "V4.16 已推送，Vercel 會自動部署。"
