解壓縮後，將檔案覆蓋到 Codespaces 專案根目錄，再執行：

chmod +x 部署_V4.16.sh
./部署_V4.16.sh

本版不需執行 Supabase SQL，也不需修改 Vercel 環境變數。
